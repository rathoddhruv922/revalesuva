import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:revalesuva/components/custom_button.dart';
import 'package:revalesuva/components/custom_text.dart';
import 'package:revalesuva/utils/app_colors.dart';
import 'package:revalesuva/utils/enums.dart';
import 'package:revalesuva/utils/navigation_helper.dart';
import 'package:revalesuva/utils/strings_constant.dart';
import 'package:revalesuva/view_models/tools/ovulation_calculator_view_model.dart';
import 'package:revalesuva/views/tools/ovulation_calculator/widget/hebrew_style_calendar.dart';
import 'package:revalesuva/views/tools/ovulation_calculator/widget/ovulation_edit_data_widget.dart';
import 'package:revalesuva/views/tools/ovulation_calculator/widget/ovulation_type_widget.dart';

class OvulationCalculatorView extends StatefulWidget {
  const OvulationCalculatorView({super.key});

  @override
  State<OvulationCalculatorView> createState() => _OvulationCalculatorViewState();
}

class _OvulationCalculatorViewState extends State<OvulationCalculatorView> {
  final OvulationCalculatorViewModel ovulationCalculatorViewModel =
      Get.put(OvulationCalculatorViewModel(), permanent: true);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) async {
        await ovulationCalculatorViewModel.onCreate();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvokedWithResult: (didPop, result) {
        NavigationHelper.onBackScreen(widget: const OvulationCalculatorView());
        ovulationCalculatorViewModel.isEditMode.value = false;
      },
      canPop: true,
      child: Scaffold(
        body: ListView(
          padding: const EdgeInsets.all(20),
          physics: const BouncingScrollPhysics(),
          children: [
            const Gap(10),
            InkWell(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: TextBodySmall(
                text: "< ${StringConstants.backTo}",
                color: AppColors.textPrimary,
                letterSpacing: 0,
              ),
            ),
            const Gap(10),
            SizedBox(
              height: 40,
              child: Row(
                children: [
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: TextHeadlineMedium(
                      text: StringConstants.ovulationCalculator,
                      color: AppColors.textPrimary,
                      letterSpacing: 0,
                    ),
                  ),
                  const Spacer(),
                  Obx(
                    () => ovulationCalculatorViewModel.isEditMode.isFalse
                        ? SimpleButton(
                            text: StringConstants.editData,
                            onPressed: () {
                              ovulationCalculatorViewModel.updateEditMode();
                            },
                          )
                        : const SizedBox(),
                  )
                ],
              ),
            ),
            const Gap(10),
            Obx(
              () => ovulationCalculatorViewModel.isEditMode.isTrue
                  ? OvulationEditDataWidget()
                  : const SizedBox(),
            ),
            const Gap(20),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Obx(
                    () => InkWell(
                      onTap: () async {
                        if (ovulationCalculatorViewModel.isEditMode.value) {
                          await ovulationCalculatorViewModel.storeOvulationDates();
                        }
                        ovulationCalculatorViewModel.selectedOvulationType.value =
                            OvulationType.menstruation;
                        ovulationCalculatorViewModel.fetchSelectedDate();
                      },
                      child: OvulationTypeWidget(
                        color: AppColors.surfaceBrand,
                        isSelected: ovulationCalculatorViewModel.selectedOvulationType.value ==
                                OvulationType.menstruation
                            ? true
                            : false,
                        title: StringConstants.menstruation,
                      ),
                    ),
                  ),
                ),
                const Gap(20),
                Flexible(
                  child: Obx(
                    () => InkWell(
                      onTap: () async {
                        if (ovulationCalculatorViewModel.isEditMode.value) {
                          await ovulationCalculatorViewModel.storeOvulationDates();
                        }
                        ovulationCalculatorViewModel.selectedOvulationType.value =
                            OvulationType.ovulation;
                        ovulationCalculatorViewModel.fetchSelectedDate();
                      },
                      child: OvulationTypeWidget(
                        color: AppColors.surfaceGreen,
                        isSelected: ovulationCalculatorViewModel.selectedOvulationType.value ==
                                OvulationType.ovulation
                            ? true
                            : false,
                        title: StringConstants.ovulation,
                      ),
                    ),
                  ),
                ),
                const Gap(20),
                Flexible(
                  child: Obx(
                    () => InkWell(
                      onTap: () async {
                        if (ovulationCalculatorViewModel.isEditMode.value) {
                          await ovulationCalculatorViewModel.storeOvulationDates();
                        }
                        ovulationCalculatorViewModel.selectedOvulationType.value =
                            OvulationType.hormonalDays;
                        ovulationCalculatorViewModel.fetchSelectedDate();
                      },
                      child: OvulationTypeWidget(
                        color: AppColors.surfaceYellow,
                        isSelected: ovulationCalculatorViewModel.selectedOvulationType.value ==
                                OvulationType.hormonalDays
                            ? true
                            : false,
                        title: StringConstants.hormonalDays,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const Gap(20),
            HebrewStyleCalendar(),
            const Gap(30),
            Obx(
              () => ovulationCalculatorViewModel.isEditMode.isTrue
                  ? SimpleButton(
                      text: StringConstants.saveData,
                      onPressed: () {
                        ovulationCalculatorViewModel.onSubmitSelectedDate();
                      },
                    )
                  : const SizedBox(),
            ),
            const Gap(80)
          ],
        ),
      ),
    );
  }
}

String getHebrewDate(DateTime date) {
  // Implement your Hebrew date conversion logic here
  // This is a placeholder - you'll need to add actual Hebrew date conversion
  return 'כ״ז'; // Example Hebrew date
}
